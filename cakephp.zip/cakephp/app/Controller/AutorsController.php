<?php
	Class AutorsController extends AppController{
		public $helpers = array('Html','Form','Session');
		public $name = 'Autors';
		
		public function index(){ 

			$this->paginate = array('order' => array('Autor.created' => 'desc'),'limit' => 10);

			$this->set('autors',$this->paginate('Autor'));
		}
		public function view($id = null){
			$this->set('autors',$this->Autor->findById($id));

		}

		public function add(){
			$posts = $this->Autor->Post->find('list', array('fields' => array('id')));
			$this->set('posts',$posts);
			if($this->request->is('post')){
				$this->Autor->create();
				if($this->Autor->save($this->request->data)){
					$this->Flash->success("Cadastro de Autor foi salvo!");
					if(count($posts)==0){
						$this->redirect(array('controller' => 'posts', 'action' => 'add'));
					}else{
						$this->redirect(array('action'=>'index'));
					}				
				}
				$this->Flash->error('Não foi possivel cadastrar o autor!');
			}

		}


		public function edit($id = null){
			$this->Autor->id = $id;
			if($this->request->is('get')){
				$this->request->data = $this->Autor->findById($id);
			}else{
				if($this->Autor->save($this->request->data)){
					$this->Flash->success('Seu post foi atualizado!');
					$this->redirect(array('action'=>'index'));
				}

			}
		}
		public function delete($id){
			if(!$this->request->is('post')){
				throw new MethodNotAllowedException();				
			}
			if($this->Autor->delete($id)){
				$this->Flash->success("O Post (id:".$id.") foi deletado!");
				$this->redirect(array('action' => 'index'));
			}
		}


	}





?>